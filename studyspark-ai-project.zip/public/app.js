const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const topicInput = $("#topicInput");
const startButton = $("#startButton");
const resultPanel = $("#resultPanel");
const resultContent = $("#resultContent");
const toast = $("#toast");
const recentTopics = $("#recentTopics");
let selectedMode = "lesson";
let goalMinutes = 20;
let doneMinutes = 0;
let currentAnswer = "";
let currentTopic = "";
let recent = [];
let toastTimer;

const modeMeta = {
  lesson: {title:"AI Tutor", subtitle:"Big questions welcome. Let's make tricky topics click."},
  articles: {title:"Article finder", subtitle:"Discover reliable reading sources for any subject."},
  flashcards: {title:"Flashcard maker", subtitle:"Turn almost any topic into active-recall cards."},
  quiz: {title:"Practice tests", subtitle:"Check what you know and learn from each answer."},
  explain: {title:"Explain a question", subtitle:"Let's untangle the tricky part, step by step."}
};

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function setMode(mode) {
  selectedMode = mode;
  $$(".mode-card").forEach(button => button.classList.toggle("selected", button.dataset.mode === mode));
  if (modeMeta[mode]) {
    $("#pageTitle").innerHTML = mode === "lesson" ? 'What do you want to <span>learn today?</span>' : `${modeMeta[mode].title} <span>with AI.</span>`;
    $("#pageSubtitle").textContent = modeMeta[mode].subtitle;
    $("#currentSection").textContent = modeMeta[mode].title;
  }
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}

// Small, safe Markdown renderer for model-generated headings, lists, emphasis and links.
// Raw HTML is escaped before formatting, so generated HTML is never executed.
function renderMarkdown(markdown) {
  let text = escapeHtml(markdown || "");
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  text = text.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  text = text.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  text = text.replace(/^# (.+)$/gm, "<h1>$1</h1>");
  text = text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  text = text.replace(/\*(.+?)\*/g, "<em>$1</em>");
  text = text.replace(/`([^`]+)`/g, "<code>$1</code>");
  const lines = text.split("\n");
  let html = "", inList = false;
  for (const line of lines) {
    const item = line.match(/^\s*[-*]\s+(.+)/);
    const numbered = line.match(/^\s*\d+[.)]\s+(.+)/);
    if (item || numbered) {
      if (!inList) { html += "<ul>"; inList = true; }
      html += `<li>${(item || numbered)[1]}</li>`;
    } else {
      if (inList) { html += "</ul>"; inList = false; }
      if (/^<h[1-3]>/.test(line)) html += line;
      else if (line.trim()) html += `<p>${line}</p>`;
    }
  }
  if (inList) html += "</ul>";
  return html;
}

function addRecent(topic) {
  recent = [topic, ...recent.filter(item => item.toLowerCase() !== topic.toLowerCase())].slice(0, 5);
  recentTopics.innerHTML = recent.map(item => `
    <button class="recent-item" data-recent="${escapeHtml(item)}">
      <span class="recent-bullet">✧</span><span>${escapeHtml(item)}</span><span>↗</span>
    </button>`).join("");
  recentTopics.querySelectorAll("[data-recent]").forEach(button => button.addEventListener("click", () => {
    topicInput.value = button.dataset.recent;
    window.scrollTo({top:0,behavior:"smooth"});
    topicInput.focus();
  }));
}

async function createStudySession() {
  const topic = topicInput.value.trim();
  if (!topic) {
    topicInput.focus();
    notify("Add a topic or question to get started.");
    return;
  }
  if (topic.length > 700) {
    notify("Please keep your topic under 700 characters.");
    return;
  }

  currentTopic = topic;
  currentAnswer = "";
  addRecent(topic);
  resultPanel.classList.remove("hidden");
  $("#examplesSection").classList.add("hidden");
  $("#resultMeta").textContent = `${$("#levelSelect").value} · ${$("#minutesSelect").selectedOptions[0].textContent}`;
  resultContent.innerHTML = '<div class="loading-state"><span class="loader"></span><span>Building your study session…</span></div>';
  startButton.disabled = true;
  startButton.innerHTML = '<span class="loader"></span> Creating your session…';

  resultPanel.scrollIntoView({behavior:"smooth",block:"start"});
  try {
    const response = await fetch("/api/study", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        topic,
        mode:selectedMode,
        level:$("#levelSelect").value,
        minutes:Number($("#minutesSelect").value)
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "The tutor could not answer just now.");
    currentAnswer = data.answer || "";
    resultContent.innerHTML = renderMarkdown(currentAnswer);
    notify("Your study session is ready!");
    doneMinutes = Math.min(goalMinutes, doneMinutes + Number($("#minutesSelect").value));
    updateGoal();
  } catch (error) {
    resultContent.innerHTML = `<div class="error-box"><h3>Let's reconnect your tutor</h3><p>${escapeHtml(error.message || "Something went wrong.")}</p><p>Check your connection and try again. If you're running the site locally, make sure the server is running and the API key is set on the server.</p></div>`;
  } finally {
    startButton.disabled = false;
    startButton.innerHTML = '<span>✦</span> Build my study session <span class="button-arrow">↗</span>';
  }
}

function updateGoal() {
  $("#minutesDone").textContent = doneMinutes;
  $("#goalValue").textContent = goalMinutes;
  $("#goalProgress").style.width = `${Math.min(100, doneMinutes / goalMinutes * 100)}%`;
}

$$(".mode-card").forEach(button => button.addEventListener("click", () => setMode(button.dataset.mode)));
$$(".topic-chip").forEach(button => button.addEventListener("click", () => {
  topicInput.value = button.dataset.topic;
  setMode("lesson");
  topicInput.focus();
  window.scrollTo({top:0,behavior:"smooth"});
}));
startButton.addEventListener("click", createStudySession);
topicInput.addEventListener("keydown", event => {
  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") createStudySession();
});

$$("[data-view]").forEach(button => button.addEventListener("click", () => {
  const view = button.dataset.view;
  if (view === "tutor") {
    setMode("lesson");
  } else {
    setMode(view === "articles" ? "articles" : view === "flashcards" ? "flashcards" : view === "quiz" ? "quiz" : "lesson");
    if (view === "progress") {
      notify("Your explored topics are listed in the sidebar panel.");
      $("#recentTopics").scrollIntoView({behavior:"smooth",block:"center"});
      return;
    }
    topicInput.focus({preventScroll:true});
    $("#composer").scrollIntoView({behavior:"smooth",block:"start"});
  }
  $$(".nav-item").forEach(item => item.classList.toggle("active", item.dataset.view === view));
  $("#currentSection").textContent = view === "tutor" ? "AI Tutor" : view === "articles" ? "Article finder" : view === "flashcards" ? "Flashcards" : view === "quiz" ? "Practice tests" : "AI Tutor";
}));

$("#addMinutes").addEventListener("click", () => {
  doneMinutes = Math.min(goalMinutes, doneMinutes + 5);
  updateGoal();
  notify(doneMinutes >= goalMinutes ? "Daily goal complete. Great work!" : "Added 5 study minutes.");
});
$("#changeGoal").addEventListener("click", () => {
  const value = prompt("Set a daily study goal in minutes (5–180):", String(goalMinutes));
  if (value === null) return;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 5 || parsed > 180) return notify("Choose a whole number between 5 and 180.");
  goalMinutes = parsed;
  doneMinutes = Math.min(doneMinutes, goalMinutes);
  updateGoal();
  notify("Daily goal updated.");
});
$("#newTopicButton").addEventListener("click", () => {
  resultPanel.classList.add("hidden");
  $("#examplesSection").classList.remove("hidden");
  topicInput.value = "";
  topicInput.focus();
  window.scrollTo({top:0,behavior:"smooth"});
});
$("#copyButton").addEventListener("click", async () => {
  if (!currentAnswer) return notify("There isn't a lesson to copy yet.");
  try {
    await navigator.clipboard.writeText(currentAnswer);
    notify("Study session copied.");
  } catch {
    notify("Clipboard access is unavailable in this browser.");
  }
});
$("#saveButton").addEventListener("click", () => {
  if (!currentTopic) return;
  addRecent(currentTopic);
  notify("Topic saved to your recent list for this session.");
});
$("#mobileMenu").addEventListener("click", () => {
  document.querySelector(".sidebar").classList.toggle("mobile-open");
});
$("#settingsButton").addEventListener("click", () => {
  $("#settingsLevel").value = $("#levelSelect").value;
  $("#settingsDialog").showModal();
});
$("#saveSettings").addEventListener("click", event => {
  event.preventDefault();
  $("#levelSelect").value = $("#settingsLevel").value;
  $("#settingsDialog").close();
  notify("Learning preference updated.");
});
$("#settingsDialog .dialog-close").addEventListener("click", () => $("#settingsDialog").close());

updateGoal();
