# StudySpark AI

A responsive study website for teens, built with HTML, CSS, vanilla JavaScript, Node.js, Express, and the OpenAI API.

## Features

- AI lessons, article-finding prompts, flashcards, practice tests, and step-by-step explanations for user-entered topics
- Grade/level and study-time controls
- Responsive desktop and mobile layout
- Topic history and a daily study-minute tracker for the current browser session
- Server-side API key handling (the key is never sent to the browser)
- Basic request validation and helpful API error messages

## Requirements

- Node.js 20+
- An OpenAI API key with API access and billing configured

## Run locally

1. Install Node.js 20 or newer.
2. In this folder, install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Put your key in `.env` as `OPENAI_API_KEY=...`. Do not share the key or commit `.env`.
5. Start the server:

   ```bash
   npm start
   ```

6. Open http://localhost:3000

The `/api/health` endpoint reports whether an API key is configured without revealing it.

## Publish with Render

1. Create a private GitHub repository and upload these project files.
2. Sign in to Render and choose **New + → Blueprint**.
3. Connect the repository and let Render read `render.yaml`.
4. In the service's Environment settings, add `OPENAI_API_KEY` with your secret key. Keep it secret and never add it to frontend files or GitHub.
5. Deploy. Render will install dependencies and run `npm start`.
6. Open the provided `onrender.com` URL and test a short topic.

If you do not want to use a blueprint, create a **Web Service** from the repository, use `npm install` as the build command and `npm start` as the start command, then add `OPENAI_API_KEY` and `OPENAI_MODEL` as environment variables.

Hosting providers' free plans and sleep limits can change. API usage may incur charges according to your OpenAI account's current pricing. Set a usage limit in your API provider account.

## Important before launch

This is a starter app, not a fully managed school platform. It does not yet have student accounts, a database, durable progress syncing, rate limiting, abuse monitoring, or a formal privacy/child-safety review. Before inviting minors to use it publicly, add server-side rate limits and cost controls, avoid collecting unnecessary personal data, publish a privacy policy and terms, and review applicable laws and school requirements. The article mode asks the model to provide reliable sources, but actual live web browsing is not wired into this version; the model must not claim it browsed unless you add a search integration.
