import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const allowedModes = new Set(["lesson", "articles", "flashcards", "quiz", "explain"]);
const maxTopicLength = 700;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/study", async (req, res) => {
  const topic = typeof req.body?.topic === "string" ? req.body.topic.trim() : "";
  const mode = typeof req.body?.mode === "string" ? req.body.mode : "lesson";
  const level = typeof req.body?.level === "string" ? req.body.level : "Grade 9";
  const minutes = Number(req.body?.minutes || 10);

  if (!topic) return res.status(400).json({ error: "Enter a topic or question first." });
  if (topic.length > maxTopicLength) return res.status(400).json({ error: "Please keep your topic under 700 characters." });
  if (!allowedModes.has(mode)) return res.status(400).json({ error: "Choose a valid study mode." });
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      error: "AI is not connected yet. Add your OPENAI_API_KEY in your hosting provider's environment variables, then restart the service."
    });
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const modeInstructions = {
    lesson: "Teach the topic from the basics. Use clear headings, an analogy, examples, key vocabulary, a recap, and 3 quick check questions.",
    articles: "Find and recommend reliable reading sources. If web search is available, use it and provide real, working URLs, publisher, title, and why each source is useful. Never invent citations or links. If you cannot browse, say so clearly and suggest reputable sites/search terms without pretending you searched.",
    flashcards: "Create 8 flashcards as a numbered list. Each card should have a clear question and concise answer. Mix recall and application.",
    quiz: "Create a 10-question practice quiz appropriate to the student's level. Show all questions first, without the answer key. Invite the student to reply with answers; then grade them and explain each answer.",
    explain: "Explain the question step by step, using simple language and an example. Help the student understand the reasoning rather than just copying an answer."
  };

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: `You are StudySpark, a warm, accurate learning coach for students aged 14–17. Use age-appropriate language and encourage independent understanding. Do not shame mistakes. Make the response useful and well-structured. Be honest about uncertainty. Do not claim you searched the web unless a search tool was actually used. Keep personal information private. Requested mode: ${mode}. ${modeInstructions[mode]}`,
      input: `Student level: ${level}\nTarget study time: ${minutes} minutes\nTopic or question: ${topic}`,
      ...(mode === "articles" ? { tools: [{ type: "web_search" }] } : {}),
      max_output_tokens: 1800
    });
    res.json({ answer: response.output_text || "I couldn't produce an answer this time. Please try again." });
  } catch (error) {
    console.error("Study request failed:", error?.message || error);
    const status = error?.status === 401 ? 502 : 500;
    res.status(status).json({
      error: error?.status === 401
        ? "The API key was rejected. Check the key in your hosting environment settings."
        : "The tutor could not answer just now. Please try again in a moment."
    });
  }
});

app.listen(port, () => {
  console.log(`StudySpark running on http://localhost:${port}`);
});
